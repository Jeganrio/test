# from django.contrib import admin
# from test_app.models import Register,Profile
# # Register your models here.
# admin.site.register(Profile)